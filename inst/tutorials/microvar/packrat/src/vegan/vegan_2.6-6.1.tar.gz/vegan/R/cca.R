"cca" <-
function (...) 
{
   UseMethod("cca")
}
